# CHANGELOG

## 2018-08-16

* Replace [placehold.it](http://placehold.it) (previous name) with [placeholder.com](http://placeholder.com) (new name)
* Use `https` protocol for image URLs
